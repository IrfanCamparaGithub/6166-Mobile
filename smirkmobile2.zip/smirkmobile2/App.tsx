import React, { useEffect, useRef, useState } from "react";
import {
  StyleSheet,
  View,
  Text,
  Button,
  Image,
  Alert,
  ScrollView,
  ActivityIndicator,
  Platform,
  Linking,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import { VideoView, useVideoPlayer } from "expo-video";
import { Buffer } from "buffer";

const API = "https://icampara-spirkappmobile.hf.space";

function buildUrl(path: string) {
  const base = API.replace(/\/+$/, "");
  const p = path.replace(/^\/+/, "");
  return `${base}/${p}`;
}
async function safeFetch(url: string, init?: RequestInit) {
  const res = await fetch(url, init as any);
  if (!res.ok) {
    let msg = `HTTP ${res.status}`;
    try {
      const txt = await res.text();
      msg = txt || msg;
    } catch {}
    throw new Error(msg);
  }
  return res;
}


function pickerMediaImages(): any {
  const IP: any = ImagePicker as any;
  if (IP?.MediaType) return [IP.MediaType.image]; 
  if (IP?.MediaTypeOptions) return IP.MediaTypeOptions.Images; 
  return undefined;
}
function pickerMediaVideos(): any {
  const IP: any = ImagePicker as any;
  if (IP?.MediaType) return [IP.MediaType.video]; 
  if (IP?.MediaTypeOptions) return IP.MediaTypeOptions.Videos; 
  return undefined;
}


function VideoInline({ uri, autoPlay = true }: { uri: string; autoPlay?: boolean }) {
  const player = useVideoPlayer(uri, () => {});
  useEffect(() => {
    if (autoPlay) {
      try {
        player.play(); 
      } catch {}
    }
    return () => {
      try {
        player.pause();
      } catch {}
    };

  }, [uri]);

  return (
    <VideoView
      player={player}
      style={{ width: 360, height: 240, alignSelf: "center", marginVertical: 8 }}
      contentFit="contain"
      allowsPictureInPicture
      nativeControls
    />
  );
}

type PickedAsset = { uri: string; fileName?: string | null; mimeType?: string | null };

export default function App() {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const [photo, setPhoto] = useState<PickedAsset | null>(null);
  const [meshImgUri, setMeshImgUri] = useState<string | null>(null);

  const [video, setVideo] = useState<PickedAsset | null>(null);
  const [meshVideoUrl, setMeshVideoUrl] = useState<string | null>(null);

  const imgUrlRef = useRef<string | null>(null);
  useEffect(() => {
    return () => {
      if (imgUrlRef.current) URL.revokeObjectURL(imgUrlRef.current);
    };
  }, []);

  // permissions
  useEffect(() => {
    (async () => {
      const media = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (media.status !== "granted") {
        Alert.alert("Permission needed", "Please allow photo/video library access.");
      }
    })();
  }, []);

  const ping = async () => {
    try {
      setErr(null);
      const res = await safeFetch(buildUrl("/health"));
      const js = await res.json();
      Alert.alert("Ping", `GET /health → ${res.status}\nhas_stack: ${js?.has_stack}`);
    } catch (e: any) {
      Alert.alert("Ping failed", String(e?.message || e));
    }
  };

  
  const pickPhoto = async () => {
    setErr(null);
    const r = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: pickerMediaImages(),
      allowsEditing: false,
      quality: 1,
      selectionLimit: 1 as any, 
    } as any);
    if (!r.canceled && r.assets?.length) {
      const a = r.assets[0];
      setPhoto({ uri: a.uri, fileName: a.fileName ?? null, mimeType: a.mimeType ?? null });
      setMeshImgUri(null);
    }
  };

  const pickVideo = async () => {
    setErr(null);
    const r = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: pickerMediaVideos(),
      allowsEditing: false,
      quality: 1,
      selectionLimit: 1 as any,
    } as any);
    if (!r.canceled && r.assets?.length) {
      const a = r.assets[0];
      setVideo({ uri: a.uri, fileName: a.fileName ?? null, mimeType: a.mimeType ?? null });
      setMeshVideoUrl(null);
    }
  };

  
  function pickImagePart(asset: PickedAsset) {
    let name = asset.fileName || "photo.jpg";
    let type = asset.mimeType || "image/jpeg";
    if (!/\.(png|jpe?g)$/i.test(name)) name = type.includes("png") ? "photo.png" : "photo.jpg";
    return { name, type };
  }
  function pickVideoPart(asset: PickedAsset) {
    let name = asset.fileName || "clip.mp4";
    let type = asset.mimeType || "video/mp4";
    if (/\.mov$/i.test(name)) name = name.replace(/\.mov$/i, ".mp4");
    if (type === "video/quicktime") type = "video/mp4";
    return { name, type };
  }


  const uploadPhotoFor3D = async () => {
    if (!photo) return Alert.alert("Pick a photo first");
    try {
      setBusy(true);
      setErr(null);
      const { name, type } = pickImagePart(photo);
      const form = new FormData();
      form.append("file", { uri: photo.uri, name, type } as any);
      const res = await safeFetch(buildUrl("/process/image"), { method: "POST", body: form as any });
      const ab = await (res as any).arrayBuffer();
      const b64 = Buffer.from(new Uint8Array(ab)).toString("base64");
      setMeshImgUri(`data:image/png;base64,${b64}`);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  const uploadVideoFor3D = async () => {
    if (!video) return Alert.alert("Pick a video first");
    try {
      setBusy(true);
      setErr(null);
      const { name, type } = pickVideoPart(video);
      const form = new FormData();
      form.append("file", { uri: video.uri, name, type } as any);
      form.append("format", "mp4"); 
      form.append("stride", "2");
      const res = await safeFetch(buildUrl("/process/video"), { method: "POST", body: form as any });
      const js = await (res as any).json();
      if (!js?.output_url) throw new Error(`No output_url from API. Response: ${JSON.stringify(js)}`);
      if (Platform.OS === "ios" && /\.webm(\?|$)/i.test(js.output_url)) {
        setMeshVideoUrl(js.output_url);
        setErr("Server returned WebM (VP9), which iOS can’t play inline. Use the button below to open in browser, or make backend prefer MP4.");
      } else {
        setMeshVideoUrl(js.output_url);
      }
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 20, paddingBottom: 60 }}>
      <Text style={styles.title}>SMIRK Mobile — 3D mesh only</Text>
      <Button title="Ping API" onPress={ping} />

      {/* PHOTO */}
      <View style={{ height: 16 }} />
      <Button title="Pick Photo" onPress={pickPhoto} />
      {photo?.uri && (
        <View style={{ marginTop: 8, alignItems: "center" }}>
          <Text style={styles.caption}>Selected</Text>
          <Image source={{ uri: photo.uri }} style={{ width: 320, height: 320, borderRadius: 12 }} />
          <View style={{ height: 10 }} />
          <Button title="Upload & Render 3D" onPress={uploadPhotoFor3D} />
        </View>
      )}
      {meshImgUri && (
        <View style={{ marginTop: 12, alignItems: "center" }}>
          <Text style={styles.caption}>3D Mesh (image)</Text>
          <Image source={{ uri: meshImgUri }} style={{ width: 320, height: 320, borderRadius: 12 }} />
        </View>
      )}

      {/* VIDEO */}
      <View style={{ height: 24 }} />
      <Button title="Pick Video" onPress={pickVideo} />
      {video?.uri && (
        <View style={{ marginTop: 8, alignItems: "center" }}>
          <Text style={styles.caption}>Selected</Text>
          <VideoInline uri={video.uri} autoPlay={false} />
          <Button title="Upload & Render 3D" onPress={uploadVideoFor3D} />
        </View>
      )}

      {meshVideoUrl && !/\.webm(\?|$)/i.test(meshVideoUrl) && (
        <View style={{ marginTop: 12, alignItems: "center" }}>
          <Text style={styles.caption}>3D Mesh (video)</Text>
          <VideoInline uri={meshVideoUrl} autoPlay />
        </View>
      )}

      {Platform.OS === "ios" && meshVideoUrl && /\.webm(\?|$)/i.test(meshVideoUrl) && (
        <View style={{ marginTop: 12, alignItems: "center" }}>
          <Button title="Open Processed Video in Browser" onPress={() => Linking.openURL(meshVideoUrl)} />
          <Text style={[styles.caption, { textAlign: "center", marginTop: 6 }]}>
            Tip: update backend writer order to MP4 first for inline iOS playback.
          </Text>
        </View>
      )}

      {busy && (
        <View style={{ marginTop: 16, alignItems: "center" }}>
          <ActivityIndicator />
        </View>
      )}
      {err && (
        <Text style={{ color: "red", marginTop: 12 }} selectable>
          {err}
        </Text>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#000" },
  title: { color: "#fff", fontSize: 26, fontWeight: "800", textAlign: "center", marginBottom: 16, marginTop: 8 },
  caption: { color: "#aaa", marginVertical: 6 },
});
